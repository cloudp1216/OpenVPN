#!/bin/bash
#


# Country name
C="CN"

# State or Province Name
ST="China"

# Locality Name
L="China"

# Organization Name
O="OpenVPN CA"

# Common Name
CN="OpenVPN CA"

# Cert Directory
key="cert"


# ==========================
path=$(cd `dirname $0`; pwd)

if [ ! -f "$path/openssl.cnf" ]; then
    echo "Configure file \"openssl.cnf\" is not exists."
    exit 1
fi

function ca() {
    touch ${key}/index.txt
    echo "01" > ${key}/serial
    echo "unique_subject = yes" > ${key}/index.txt.attr

    # Create CA key and cert. 
    openssl req -new -newkey rsa:1024 -days 3650 -nodes -x509 \
        -extensions easyrsa_ca -keyout ${key}/ca.key -out ${key}/ca.crt \
        -subj "/C=${C}/ST=${ST}/L=${L}/O=${O}/CN=${CN}" \
        -config openssl.cnf 2>/dev/null

    chmod 0600 ${key}/ca.key
}

function server() {
    # Create server key and cert.
    openssl req -new -nodes -config openssl.cnf \
        -extensions server \
        -keyout ${key}/server.key \
        -out ${key}/server.csr \
        -subj "/C=${C}/ST=${ST}/L=${L}/O=${O}/CN=${CN}"

    openssl ca -batch -config openssl.cnf \
        -extensions server \
        -in ${key}/server.csr \
        -out ${key}/server.crt
  
    chmod 0600 ${key}/server.key
}

function dh() {
    # Create DH parameters
    openssl dhparam -out ${key}/dh2048.pem 2048
    echo
}

function create_ovpn() {
cfg="client.ovpn"
cli="./${key}/$cfg"
if [ -f ./${key}/ca.crt ]; then
cat > $cli <<EOF
# - OpenVPN Client Configure File -


client
dev tun
proto tcp
remote 127.0.0.1 443
nobind
auth-user-pass
auth-nocache
resolv-retry infinite
persist-key
persist-tun
remote-cert-tls server
data-ciphers AES-128-GCM
windows-driver wintun
reneg-sec 0
verb 3

EOF
echo "<ca>" >> $cli
cat ./${key}/ca.crt >> $cli
echo "</ca>" >> $cli
echo "" >> $cli
echo -n "Create client configure file: '`echo -e "\033[36m$path/$key/$cfg\033[0m"`'"
echo
fi
}

function main() {
    cd $path
    if [ ! -d ${key} ]; then
        mkdir -p ${key}
        ca
        server
        dh
        create_ovpn
    fi 
}

main


